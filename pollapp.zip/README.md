This app idea is from freecodecamp Dynamic web applications project. 
Technologies used are HTML, CSS, SASS, PHP, MYSQL, JAVASCRIPT, AJAX, JQUERY, CHART.JS