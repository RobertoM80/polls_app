 <footer class='footer navbar-fixed-bottom'>
   <h5 class='text-center'>&copy Copyright <span class='date'></span>  - <a id='hm' href='http://robertom80.github.io'> Roberto Mirabella </a></h5>
 </footer>
</div>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Javascript
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  <script src="node_modules/chart.js/dist/Chart.min.js"></script>
  <script type="text/javascript" src="javascript/script.min.js"></script>
</body>
</html>
